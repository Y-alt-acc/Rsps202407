<?php
require 'commonfunction.php';
redirect("./slideShowPage.php");
?>