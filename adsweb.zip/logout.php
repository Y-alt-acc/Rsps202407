<?php
include_once("./commonFunction.php");
session_destroy();
redirect("./home.html");
?>